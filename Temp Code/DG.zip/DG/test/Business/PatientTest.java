/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Carl
 */
public class PatientTest {
    
    public PatientTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getPatientId method, of class Patient.
     */
    @Test
    public void testGetPatientId() {
        System.out.println("getPatientId");
        Patient instance = new Patient();
        String expResult = "";
        String result = instance.getPatientId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setPatientId method, of class Patient.
     */
    @Test
    public void testSetPatientId() {
        System.out.println("setPatientId");
        String patientId = "";
        Patient instance = new Patient();
        instance.setPatientId(patientId);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFirstName method, of class Patient.
     */
    @Test
    public void testGetFirstName() {
        System.out.println("getFirstName");
        Patient instance = new Patient();
        String expResult = "";
        String result = instance.getFirstName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFirstName method, of class Patient.
     */
    @Test
    public void testSetFirstName() {
        System.out.println("setFirstName");
        String firstName = "";
        Patient instance = new Patient();
        instance.setFirstName(firstName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLastName method, of class Patient.
     */
    @Test
    public void testGetLastName() {
        System.out.println("getLastName");
        Patient instance = new Patient();
        String expResult = "";
        String result = instance.getLastName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setLastName method, of class Patient.
     */
    @Test
    public void testSetLastName() {
        System.out.println("setLastName");
        String lastName = "";
        Patient instance = new Patient();
        instance.setLastName(lastName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getInsurance method, of class Patient.
     */
    @Test
    public void testGetInsurance() {
        System.out.println("getInsurance");
        Patient instance = new Patient();
        String expResult = "";
        String result = instance.getInsurance();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setInsurance method, of class Patient.
     */
    @Test
    public void testSetInsurance() {
        System.out.println("setInsurance");
        String insurance = "";
        Patient instance = new Patient();
        instance.setInsurance(insurance);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getMedicaidNumber method, of class Patient.
     */
    @Test
    public void testGetMedicaidNumber() {
        System.out.println("getMedicaidNumber");
        Patient instance = new Patient();
        String expResult = "";
        String result = instance.getMedicaidNumber();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setMedicaidNumber method, of class Patient.
     */
    @Test
    public void testSetMedicaidNumber() {
        System.out.println("setMedicaidNumber");
        String medicaidNumber = "";
        Patient instance = new Patient();
        instance.setMedicaidNumber(medicaidNumber);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of display method, of class Patient.
     */
    @Test
    public void testDisplay() {
        System.out.println("display");
        Patient instance = new Patient();
        instance.display();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of selectDB method, of class Patient.
     */
    @Test
    public void testSelectDB() throws Exception {
        System.out.println("selectDB");
        String pId = "";
        Patient instance = new Patient();
        instance.selectDB(pId);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of insertDB method, of class Patient.
     */
    @Test
    public void testInsertDB() throws Exception {
        System.out.println("insertDB");
        String pId = "";
        String fn = "";
        String ln = "";
        String ins = "";
        String mednum = "";
        Patient instance = new Patient();
        instance.insertDB(pId, fn, ln, ins, mednum);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateDBAdmin method, of class Patient.
     */
    @Test
    public void testUpdateDBAdmin() throws Exception {
        System.out.println("updateDBAdmin");
        Patient instance = new Patient();
        instance.updateDBAdmin();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateDB method, of class Patient.
     */
    @Test
    public void testUpdateDB() throws Exception {
        System.out.println("updateDB");
        Patient instance = new Patient();
        instance.updateDB();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteDB method, of class Patient.
     */
    @Test
    public void testDeleteDB() throws Exception {
        System.out.println("deleteDB");
        Patient instance = new Patient();
        instance.deleteDB();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Patient.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Patient.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
