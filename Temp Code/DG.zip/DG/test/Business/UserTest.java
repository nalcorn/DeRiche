/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Carl
 */
public class UserTest {
    
    public UserTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getUserId method, of class User.
     */
    @Test
    public void testGetUserId() {
        System.out.println("getUserId");
        User instance = new User();
        String expResult = "110";
        instance.setUserId(expResult);
        String result = instance.getUserId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of setUserId method, of class User.
     */
    @Test
    public void testSetUserId() {
        System.out.println("setUserId");
        String userId = "2";
        User instance = new User();
        instance.setUserId(userId);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of getUserName method, of class User.
     */
    @Test
    public void testGetUserName() {
        System.out.println("getUserName");
        User instance = new User();
        String expResult = "2";
        instance.setUserName(expResult);
        String result = instance.getUserName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setUserName method, of class User.
     */
    @Test
    public void testSetUserName() {
        System.out.println("setUserName");
        String userName = "";
        User instance = new User();
        instance.setUserName(userName);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of getPass method, of class User.
     */
    @Test
    public void testGetPass() {
        System.out.println("getPass");
        User instance = new User();
        String expResult = "3";
        instance.setPass(expResult);
        String result = instance.getPass();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setPass method, of class User.
     */
    @Test
    public void testSetPass() {
        System.out.println("setPass");
        String pass = "";
        User instance = new User();
        instance.setPass(pass);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of getPin method, of class User.
     */
    @Test
    public void testGetPin() {
        System.out.println("getPin");
        User instance = new User();
        String expResult = "4";
        instance.setPin(expResult);
        String result = instance.getPin();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setPin method, of class User.
     */
    @Test
    public void testSetPin() {
        System.out.println("setPin");
        String pin = "";
        User instance = new User();
        instance.setPin(pin);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getFn method, of class User.
     */
    @Test
    public void testGetFn() {
        System.out.println("getFn");
        User instance = new User();
        String expResult = "5";
        instance.setFn(expResult);
        String result = instance.getFn();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setFn method, of class User.
     */
    @Test
    public void testSetFn() {
        System.out.println("setFn");
        String fn = "";
        User instance = new User();
        instance.setFn(fn);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getLn method, of class User.
     */
    @Test
    public void testGetLn() {
        System.out.println("getLn");
        User instance = new User();
        String expResult = "6";
        instance.setLn(expResult);
        String result = instance.getLn();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setLn method, of class User.
     */
    @Test
    public void testSetLn() {
        System.out.println("setLn");
        String ln = "";
        User instance = new User();
        instance.setLn(ln);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getT method, of class User.
     */
    @Test
    public void testGetT() {
        System.out.println("getT");
        User instance = new User();
        String expResult = "7";
        instance.setT(expResult);
        String result = instance.getT();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setT method, of class User.
     */
    @Test
    public void testSetT() {
        System.out.println("setT");
        String t = "";
        User instance = new User();
        instance.setT(t);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of getC method, of class User.
     */
    @Test
    public void testGetC() {
        System.out.println("getC");
        User instance = new User();
        String expResult = "10";
        instance.setC(expResult);
        String result = instance.getC();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        
    }

    /**
     * Test of setC method, of class User.
     */
    @Test
    public void testSetC() {
        System.out.println("setC");
        String c = "";
        User instance = new User();
        instance.setC(c);
        // TODO review the generated test code and remove the default call to fail.
        
    }

   
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        User.main(args);
        // TODO review the generated test code and remove the default call to fail.
        
    }
    
}
