/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;
 import java.sql.*;  
/**
 *
 * @author Carl
 */
public class database_connection {
   
  
public static String[] db_connection(String UId){  

 String id = UId;
 String pw = "";
 String ur = "";
    try{  
Class.forName("com.mysql.jdbc.Driver");  
Connection con=DriverManager.getConnection(  
"jdbc:mysql://localhost:3306/deriche","root","password");  
//here sonoo is database name, root is username and password  
Statement stmt=con.createStatement();  
ResultSet rs=stmt.executeQuery("select * from user where UserName='"+id+"'");  
while(rs.next())
{    
System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"  "+rs.getString(7));
id = rs.getString(2);
pw = rs.getString(3);
ur= rs.getString(7);
} 
con.close(); 



return new String[] {pw, id, ur};

}catch(Exception e){
    System.out.println(e);
return null;
}
	
}  
}  

