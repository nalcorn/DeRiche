package Dao;

import java.sql.PreparedStatement;

/**
 * 
 * 
 * Date: 3/01/2017
 *
 * @author Cameron Randolph
 *
 * @version 1.2
 */
public interface Accessible {

    public abstract PreparedStatement setStatementValues(PreparedStatement statement, Object[] values);
    
}
