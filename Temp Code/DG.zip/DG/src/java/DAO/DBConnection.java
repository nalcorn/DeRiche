package DAO;

import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * The {@link DAO.DBConnection} class contains all the methods needed for database access in the DeRiche project.<br>
 * Any class accessing the database through {@link DAO.DBConnection} will need to implement {@link DAO.Accessible}. By implementing {@link DAO.Accessible} the class' attribute names must directly correspond to the column names for the matching table in the database.
 *
 * Date: 2/23/2017
 *
 * @author Cameron Randolph
 * @author Carl Moon
 *
 * @version 1.0
 */
public final class DBConnection {

    /**
     * Handles all select statements required by the DeRiche business objects.<br>
     * This method has the ability to select any value from the database desribed in the establish() method and return it as an {@link java.lang.Object}.
     *
     * @author Carl Moon
     * @author Cameron Randolph
     *
     * @param sql the statement to be passed to the database
     * @param var the variable to be used to set the {@link java.lan.String} for the {@link java.sql.PreparedStatement}
     *
     * @return an {@link java.lang.Object} array holding all values selected from the database
     */
    public static Object[] select(String sql, String var) throws SQLException, ClassNotFoundException {
        
        int columnCount;
        Object[] data;
        Connection connection;
        PreparedStatement statement;
        ResultSet rs;
        
        connection = establish();
        connection.prepareStatement(sql);
        statement = connection.prepareStatement(sql);
        statement.setString(1, var);
        rs = statement.executeQuery();
        columnCount = rs.getMetaData().getColumnCount();
        data = new Object[columnCount];
            
        while (rs.next()) {
            for (int i = 0; i < columnCount; i++) {
                data[i] = rs.getObject(i + 1);
            }
        }
        
        return data;
    }

    public static int insertDB(Accessible object, Object[] values) throws SQLException, ClassNotFoundException {
    	
        int executed;
        Connection connection;
        PreparedStatement statement;

        connection = establish();
        statement = connection.prepareStatement(generateSQL(object, 'I'));
        statement = object.setStatementValues(statement, values);
        executed = statement.executeUpdate();
        
        System.out.println(generateSQL(object, 'I'));

        return executed;
    }

    private static String generateSQL(Accessible object, char var) {

        if (var == 'I') {
    	    Field[] field;
            String sql;
            String names;
            String marks;
            
    	    field = object.getClass().getDeclaredFields();
            sql = "insert into " + getClassName(object) + "(";
            names = "";
            marks = "";
    		
    	    for (int i = 0; i < field.length; i++) {
                if (i < field.length - 1) {
                    names += field[i].getName() + ", ";
                    marks += "?, ";
                } else {
                    names += field[i].getName() + ") values(";
                    marks += "?)";
                }
    	    }

            return sql + names + marks;
        }
        
        return "Not Found";
    }

    /**
     * Retrieves the class name from the object passed to it.<br>
     * This method only gives the name of the class. Any parent classes are removed from the return value.
     *
     * @return a {@link java.lang.String} representing the name of the class
     */
    private static String getClassName(Object object) {
    	String name;
    	int index;
    	
    	name = "";
    	index = object.getClass().getName().lastIndexOf('.') + 1;
    	
    	for (int i = index; i < (object.getClass().getName().length()); i++) {
    		name += object.getClass().getName().charAt(i);
    	}
    	
    	return name;
    }

    /**
     * Establishes a connection to the DeRiche database for every method in the {@link dataAccess.DBConnection} class.
     *
     * @return a {@link java.sql.Connection} already linked to the DeRiche database
     */
    public static Connection establish() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.jdbc.Driver");
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/deriche", "root", "password");
        return connection;    
    }
}
